package com.massivecraft.factions.cmd;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.massivecraft.factions.Factions;
import com.massivecraft.factions.Perm;
import com.massivecraft.factions.Rel;
import com.massivecraft.factions.cmd.req.ReqHasntFaction;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.factions.entity.MConf;
import com.massivecraft.factions.entity.SubTypeConf;
import com.massivecraft.factions.event.EventFactionsCreate;
import com.massivecraft.factions.event.EventFactionsMembershipChange;
import com.massivecraft.factions.event.EventFactionsMembershipChange.MembershipChangeReason;
import com.massivecraft.factions.util.MiscUtil;
import com.massivecraft.massivecore.cmd.req.ReqHasPerm;
import com.massivecraft.massivecore.store.MStore;

import java.util.ArrayList;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class CmdFactionsCreate extends FactionsCommand
{
	// -------------------------------------------- //
	// CONSTRUCT
	// -------------------------------------------- //
	
	public CmdFactionsCreate()
	{
		// Aliases
		this.addAliases("create");

		// Args
		this.addRequiredArg("subtype");
		this.addRequiredArg("name");

		// Requirements
		this.addRequirements(ReqHasntFaction.get());
		this.addRequirements(ReqHasPerm.get(Perm.CREATE.node));
	}

    // -------------------------------------------- //
    // Cooldowns
    // -------------------------------------------- //

    private Cache<UUID, Long> nextUseCache = CacheBuilder.newBuilder()
            .expireAfterWrite(12, TimeUnit.HOURS)
            .build();

	// -------------------------------------------- //
	// OVERRIDE
	// -------------------------------------------- //
	
	@Override
	public void perform()
	{
		// Args
		String subType = this.arg(0);
		String newName = this.arg(1);
		
		// Verify
        if(!msender.getSender().hasPermission("factions.cooldown.bypass") && nextUseCache.getIfPresent(msender.getPlayer().getUniqueId()) != null) {
            Long nextUse = nextUseCache.getIfPresent(msender.getPlayer().getUniqueId());
            if(System.currentTimeMillis() < nextUse) {
                msg("<b>You must wait " + MiscUtil.getTimeSpan(nextUse - System.currentTimeMillis()) + " until you can use this command!");
                return;
            } else {
                nextUseCache.invalidate(msender.getPlayer().getUniqueId());
            }
        }
		if (FactionColl.get().isNameTaken(newName))
		{
			msg("<b>That name is already in use.");
			return;
		}
        if(!SubTypeConf.get().isSubTypeValid(subType)) {
            msg("<b>The Subtype you specified is not valid!");
            msg("<i>The following Subtypes are available: " + SubTypeConf.get().getAvailableSubTypes());
			msg("<i>Go to /warp subtype to learn more.");
            return;
        }
		
		ArrayList<String> nameValidationErrors = FactionColl.get().validateName(newName);
		if (nameValidationErrors.size() > 0)
		{
			sendMessage(nameValidationErrors);
			return;
		}

		// Pre-Generate Id
		String factionId = MStore.createId();
		
		// Event
		EventFactionsCreate createEvent = new EventFactionsCreate(sender, factionId, newName);
		createEvent.run();
		if (createEvent.isCancelled()) return;
		
		// Apply
		Faction faction = FactionColl.get().create(factionId);
		faction.setName(newName);
        faction.setSubType(SubTypeConf.get().getCleanSubType(subType));
		
		msender.setRole(Rel.LEADER);
		msender.setFaction(faction);
		
		EventFactionsMembershipChange joinEvent = new EventFactionsMembershipChange(sender, msender, faction, MembershipChangeReason.CREATE);
		joinEvent.run();
		// NOTE: join event cannot be cancelled or you'll have an empty faction

        // Update cooldown
        nextUseCache.put(msender.getPlayer().getUniqueId(), System.currentTimeMillis() + 43200000L);

		// Inform
		msg("<i>You created the faction %s", faction.getName(msender));
		msg("<i>You should now: %s", Factions.get().getOuterCmdFactions().cmdFactionsDescription.getUseageTemplate());

		// Log
		if (MConf.get().logFactionCreate)
		{
			Factions.get().log(msender.getName()+" created a new faction: "+newName);
		}
	}
}
