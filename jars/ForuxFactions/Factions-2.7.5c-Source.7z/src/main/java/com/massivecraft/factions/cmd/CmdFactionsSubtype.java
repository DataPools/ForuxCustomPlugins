package com.massivecraft.factions.cmd;

import com.massivecraft.factions.Perm;
import com.massivecraft.factions.Rel;
import com.massivecraft.factions.cmd.req.ReqHasFaction;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.MPlayer;
import com.massivecraft.factions.entity.SubTypeConf;
import com.massivecraft.factions.integration.Perms;
import com.massivecraft.massivecore.cmd.req.ReqHasPerm;
import com.massivecraft.massivecore.util.Txt;

public class CmdFactionsSubtype extends FactionsCommand
{
	// -------------------------------------------- //
	// CONSTRUCT
	// -------------------------------------------- //

	public CmdFactionsSubtype()
	{
		// Aliases
		this.addAliases("subtype", "st");

		// Args
		this.addRequiredArg("subtype");

		// Requirements
		this.addRequirements(ReqHasFaction.get());
		this.addRequirements(ReqHasPerm.get(Perm.SUBTYPE.node));
	}

	// -------------------------------------------- //
	// OVERRIDE
	// -------------------------------------------- //
	
	@Override
	public void perform()
	{
		// Args
		String subType = this.arg(0);
		
		// Verify
		if (msender.getRole() != Rel.LEADER)
		{
			sender.sendMessage(Txt.parse("<b>You must be leader of the faction to set the Subtype!"));
			return;
		}

		if(!msenderFaction.getSubType().equals(Faction.UNSPECIFIED_SUBTYPE)) {
			msg("<b>Your Faction Subtype has already been set!");
			return;
		}

        if(!SubTypeConf.get().isSubTypeValid(subType)) {
            msg("<b>The Subtype you specified is not valid!");
            msg("<i>The following Subtypes are available: " + SubTypeConf.get().getAvailableSubTypes());
			msg("<i>Go to /warp subtype to learn more");
			return;
        }
		
		// Apply
        msenderFaction.setSubType(SubTypeConf.get().getCleanSubType(subType));

        // Update users
        for(MPlayer mp : msenderFaction.getMPlayers()) {
            for(String permission : SubTypeConf.get().subTypePermissions.get(msenderFaction.getSubType())) {
                Perms.givePermission(mp, permission);
            }
        }

		// Inform
		msg("<i>You have set your Faction's Subtype to %s", subType);
	}
}
