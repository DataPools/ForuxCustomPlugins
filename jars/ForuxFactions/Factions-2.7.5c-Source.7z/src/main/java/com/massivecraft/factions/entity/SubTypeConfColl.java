package com.massivecraft.factions.entity;

import com.massivecraft.factions.Const;
import com.massivecraft.factions.Factions;
import com.massivecraft.massivecore.MassiveCore;
import com.massivecraft.massivecore.store.Coll;
import com.massivecraft.massivecore.store.MStore;

public class SubTypeConfColl extends Coll<SubTypeConf>
{
	// -------------------------------------------- //
	// INSTANCE & CONSTRUCT
	// -------------------------------------------- //

	private static SubTypeConfColl i = new SubTypeConfColl();
	public static SubTypeConfColl get() { return i; }
	private SubTypeConfColl()
	{
		super(Const.COLLECTION_SUBTYPES, SubTypeConf.class, MStore.getDb(), Factions.get());
	}
	
	// -------------------------------------------- //
	// OVERRIDE
	// -------------------------------------------- //
	
	@Override
	public void init()
	{
		super.init();
		SubTypeConf.i = this.get(MassiveCore.INSTANCE, true);
	}
}
