package com.massivecraft.factions;

import com.massivecraft.massivecore.util.Txt;

public class Lang
{
	public static final String FACTION_NODESCRIPTION = Txt.parse("<em><silver>no description set");
	public static final String FACTION_NOMOTD = Txt.parse("<em><silver>no message of the day set");
	public static final String PLAYER_NOTITLE = Txt.parse("<em><silver>no title set");
}
