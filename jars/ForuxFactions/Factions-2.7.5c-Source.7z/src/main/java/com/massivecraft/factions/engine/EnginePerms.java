package com.massivecraft.factions.engine;

import com.massivecraft.factions.Factions;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.MPlayer;
import com.massivecraft.factions.entity.SubTypeConf;
import com.massivecraft.factions.event.EventFactionsDisband;
import com.massivecraft.factions.event.EventFactionsMembershipChange;
import com.massivecraft.factions.event.EventFactionsMembershipChange.MembershipChangeReason;
import com.massivecraft.factions.integration.Perms;
import com.massivecraft.massivecore.EngineAbstract;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;

public class EnginePerms extends EngineAbstract
{
	// -------------------------------------------- //
	// INSTANCE & CONSTRUCT
	// -------------------------------------------- //

	private static EnginePerms i = new EnginePerms();
	public static EnginePerms get() { return i; }
	public EnginePerms() {}
	
	// -------------------------------------------- //
	// OVERRIDE
	// -------------------------------------------- //
	
	@Override
	public Plugin getPlugin()
	{
		return Factions.get();
	}

	// -------------------------------------------- //
	// REMOVE ON LEAVE
	// -------------------------------------------- //
	
	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void removeOnLeave(final EventFactionsMembershipChange event) {
		// If a player is leaving or being kicked from the faction ...
		if (event.getReason() != MembershipChangeReason.LEAVE && event.getReason() != MembershipChangeReason.KICK) return;

		// ... and the Faction has a valid sub-type ...
		final MPlayer mPlayer = event.getMPlayer();
		Faction faction = mPlayer.getFaction();
		if(faction.getSubType().equals(Faction.UNSPECIFIED_SUBTYPE)) return;

		// ... then remove all their Faction's sub-type permissions
        //     we remove the permissions over a period of time to ensure each one is removed fully
        int k = 5;
		for(final String permission : SubTypeConf.get().subTypePermissions.get(faction.getSubType())) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    boolean success = Perms.removePermission(mPlayer, permission);
                    if(!success) {
                        Bukkit.getLogger().severe("EventFactionsMembershipChange :: Failed to remove permission '" + permission + "' from player: " + mPlayer.getName());
                    }
                }
            }.runTaskLater(Factions.get(), k);
            k += 10;
		}
	}
	
	// -------------------------------------------- //
	// REMOVE ON DISBAND
	// -------------------------------------------- //
	
	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void removeOnDisband(final EventFactionsDisband event) {
		Faction faction = event.getFaction();
		if(faction.getSubType().equals(Faction.UNSPECIFIED_SUBTYPE)) return;
		List<String> grantedPermissions = SubTypeConf.get().subTypePermissions.get(faction.getSubType());

		for(final MPlayer mp : faction.getMPlayers()) {
            int k = 5;
            for(final String permission : grantedPermissions) {
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        boolean success = Perms.removePermission(mp, permission);
                        if(!success) {
                            Bukkit.getLogger().severe("EventFactionsMembershipChange :: Failed to remove permission '" + permission + "' from player: " + mp.getName());
                        }
                    }
                }.runTaskLater(Factions.get(), k);
                k += 10;
            }
		}

	}
	
	// -------------------------------------------- //
	// GIVE ON JOIN & CREATE
	// -------------------------------------------- //

	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void giveOnJoin(EventFactionsMembershipChange event) {
		if(event.getReason() != MembershipChangeReason.JOIN && event.getReason() != MembershipChangeReason.CREATE) return;

		Faction faction = event.getNewFaction();
		if(faction.getSubType().equals(Faction.UNSPECIFIED_SUBTYPE)) return;

		MPlayer mp = event.getMPlayer();

		for(String permission : SubTypeConf.get().subTypePermissions.get(faction.getSubType())) {
			Perms.givePermission(mp, permission);
		}
	}

	// -------------------------------------------- //
	// SHARED
	// -------------------------------------------- //

	private void removeAll(MPlayer player) {

	}
}
