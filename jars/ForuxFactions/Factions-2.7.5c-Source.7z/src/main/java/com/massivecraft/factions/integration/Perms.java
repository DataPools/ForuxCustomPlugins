package com.massivecraft.factions.integration;

import com.massivecraft.factions.entity.MPlayer;
import net.milkbowl.vault.permission.Permission;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.UUID;

public class Perms
{
    // -------------------------------------------- //
    // STATE
    // -------------------------------------------- //
    private static Permission permissions = null;

    public static boolean isEnabled()
    {
        return permissions != null;
    }

    public static void hookPermissions() {
        RegisteredServiceProvider<Permission> permissionProvider = Bukkit.getServer().getServicesManager().getRegistration(net.milkbowl.vault.permission.Permission.class);
        if (permissionProvider != null) {
            permissions = permissionProvider.getProvider();
        }
    }

    // -------------------------------------------- //
    // UTIL
    // -------------------------------------------- //

    public static boolean givePermission(MPlayer sender, String permissionNode) {
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(UUID.fromString(sender.getId()));
        return permissions.playerAdd(null, offlinePlayer, permissionNode);
    }

    public static boolean removePermission(MPlayer sender, String permissionNode) {
        if(sender.getId() == null || sender.getId().length() < 28) {
            Bukkit.getLogger().severe("Unable to remove permission '" + permissionNode + "' from " + sender.getName() + " because their ID is invalid!?");
        }

        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(UUID.fromString(sender.getId()));
        return permissions.playerRemove(null, offlinePlayer, permissionNode);
    }
}
