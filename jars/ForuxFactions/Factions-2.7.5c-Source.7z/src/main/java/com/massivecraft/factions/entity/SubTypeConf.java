package com.massivecraft.factions.entity;

import com.massivecraft.massivecore.store.Entity;
import com.massivecraft.massivecore.util.MUtil;

import java.util.List;
import java.util.Map;

public class SubTypeConf extends Entity<SubTypeConf>
{
	// -------------------------------------------- //
	// META
	// -------------------------------------------- //
	
	protected static transient SubTypeConf i;
	public static SubTypeConf get() { return i; }
	
	// -------------------------------------------- //
	// OVERRIDE: ENTITY
	// -------------------------------------------- //
	
	@Override
	public SubTypeConf load(SubTypeConf that)
	{
		super.load(that);
		return this;
	}
	
	// -------------------------------------------- //
	// SUB TYPES
	// -------------------------------------------- //
	
	public List<String> subTypes = MUtil.list("type1", "type2");

    public String getAvailableSubTypes() {
        String ret = "";
        for(String str : subTypes) {
            ret += str + ", ";
        }

        return ret.substring(0, ret.length()-2).trim();
    }

	// -------------------------------------------- //
	// SUB TYPE PERMISSIONS
	// -------------------------------------------- //

	public Map<String, List<String>> subTypePermissions = MUtil.map(
			"type1",
				MUtil.list(
						"permission.node.1",
						"permission.node.2"),
			"type2",
				MUtil.list(
						"permission.node.3",
						"permission.node.4")
	);

    // -------------------------------------------- //
    // VALIDATION
    // -------------------------------------------- //

    public boolean isSubTypeValid(String input) {
        for(String str : subTypes) {
            if(input.equalsIgnoreCase(str)) {
                return true;
            }
        }

        return false;
    }

    public String getCleanSubType(String input) {
        for(String str : subTypes) {
            if(input.equalsIgnoreCase(str)) {
                return str;
            }
        }

        return null;
    }
}
