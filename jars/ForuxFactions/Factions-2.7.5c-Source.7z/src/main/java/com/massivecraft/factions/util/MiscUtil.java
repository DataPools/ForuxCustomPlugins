package com.massivecraft.factions.util;

import org.bukkit.ChatColor;

import java.util.Arrays;
import java.util.HashSet;

public class MiscUtil
{	
	// Inclusive range
	public static long[] range(long start, long end) {
		long[] values = new long[(int) Math.abs(end - start) + 1];
		
		if (end < start) {
			long oldstart = start;
			start = end;
			end = oldstart;
		}
	
		for (long i = start; i <= end; i++) {
			values[(int) (i - start)] = i;
		}
		
		return values;
	}
	
	public static HashSet<String> substanceChars = new HashSet<String>(Arrays.asList(new String []{
	"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", 
	"I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", 
	"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", 
	"s", "t", "u", "v", "w", "x", "y", "z"
	}));
			
	public static String getComparisonString(String str)
	{
		String ret = "";
		
		str = ChatColor.stripColor(str);
		str = str.toLowerCase();
		
		for (char c : str.toCharArray())
		{
			if (substanceChars.contains(String.valueOf(c)))
			{
				ret += c;
			}
		}
		return ret.toLowerCase();
	}

	public static String getTimeSpan(long timeInMilis) {
		StringBuilder time = new StringBuilder();
		double[] timesList = new double[4];
		String[] unitsList = new String[]{"second", "minute", "hour", "day"};

		timesList[0] = timeInMilis / 1000;
		timesList[1] = Math.floor(timesList[0] / 60);
		timesList[0] = timesList[0] - (timesList[1] * 60);
		timesList[2] = Math.floor(timesList[1] / 60);
		timesList[1] = timesList[1] - (timesList[2] * 60);
		timesList[3] = Math.floor(timesList[2] / 24);
		timesList[2] = timesList[2] - (timesList[3] * 24);

		for (int j = 3; j > -1; j--) {
			double d = timesList[j];
			if (d < 1) continue;
			time.append((int) d).append(" ").append(unitsList[j]).append(d > 1 ? "s " : " ");
		}

		return time.toString().trim();
	}
}

